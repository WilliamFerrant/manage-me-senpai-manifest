import json
import logging
import os
import sys
import traceback
from datetime import datetime

from bridge_features import FeatureService
from config_manager import Config, DEFAULT_CONFIG, PROFILE_KEYS
from logic import DofusLogic


logging.basicConfig(level=logging.ERROR, stream=sys.stderr)
logger = logging.getLogger("ManageMeSenpai.Bridge")


class BackendBridge:
    def __init__(self):
        self.config = Config()
        self.logic = DofusLogic(self.config)
        self.last_error = ""
        self.logic.set_error_callback(self._capture_error)
        self.features = FeatureService(self.config, self.logic, error_callback=self._capture_error)
        self.activity_log = []
        self.app_version = self._read_app_version()
        self._append_log("Bridge backend initialisé.")

    def _read_app_version(self):
        version_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "version.txt")
        try:
            with open(version_path, "r", encoding="utf-8") as handle:
                return (handle.read().strip() or "1.1.0")
        except OSError:
            return "1.1.0"

    def _append_log(self, message, level="info"):
        entry = {
            "timestamp": datetime.utcnow().strftime("%H:%M:%S"),
            "level": level,
            "message": str(message or ""),
        }
        self.activity_log.append(entry)
        if len(self.activity_log) > 120:
            self.activity_log = self.activity_log[-120:]

    def _capture_error(self, message):
        self.last_error = str(message or "")
        if self.last_error:
            self._append_log(self.last_error, "error")

    def _serialize_accounts(self, accounts):
        leader_name = self.config.data.get("leader_name", "")
        focus_hotkeys = self.config.data.get("account_focus_hotkeys", {})
        serialized = []
        for index, account in enumerate(accounts):
            serialized.append(
                {
                    "index": index + 1,
                    "name": account.get("name", ""),
                    "active": bool(account.get("active", False)),
                    "team": account.get("team", "Team 1"),
                    "classe": account.get("classe", "Inconnu"),
                    "initiative": int(account.get("initiative", 0)),
                    "is_leader": account.get("name", "") == leader_name,
                    "focus_hotkey": focus_hotkeys.get(account.get("name", ""), ""),
                    "hwnd": int(account.get("hwnd", 0) or 0),
                }
            )
        return serialized

    def _settings_snapshot(self):
        keys = [
            "current_mode",
            "volume_level",
            "toolbar_active",
            "toolbar_x",
            "toolbar_y",
            "toolbar_width",
            "toolbar_height",
            "toolbar_layout",
            "show_tooltips",
            "return_to_leader",
            "spam_click_active",
            "auto_group_enabled",
            "auto_trade_enabled",
            "click_speed",
            "zaap_delay",
            "radial_menu_active",
            "radial_menu_hotkey",
            "compact_mode",
            "prev_key",
            "next_key",
            "leader_key",
            "sync_key",
            "sync_right_key",
            "treasure_key",
            "swap_xp_drop_key",
            "toggle_app_key",
            "paste_enter_key",
            "invite_group_key",
            "auto_zaap_key",
            "refresh_key",
            "sort_taskbar_key",
            "calib_key",
            "game_inv_key",
            "game_char_key",
            "game_spell_key",
            "game_haven_key",
            "active_profile",
            "update_manifest_url",
            "update_channel",
            "last_update_check_utc",
        ]
        snapshot = {}
        for key in keys:
            snapshot[key] = self.config.data.get(key, DEFAULT_CONFIG.get(key))
        return snapshot

    def _calibration_snapshot(self):
        macro_positions = self.config.data.get("macro_positions", {})
        rows = []
        for key in sorted(macro_positions.keys()):
            rows.append({"key": key, "value": macro_positions.get(key)})
        return rows

    def _visual_macros_snapshot(self):
        macros = self.config.data.get("visual_macros", {}) or {}
        rows = []
        for key in sorted(macros.keys(), key=str.casefold):
            macro = macros.get(key) or {}
            rows.append(
                {
                    "name": key,
                    "button": macro.get("button", "left"),
                    "position": [macro.get("x", 0.0), macro.get("y", 0.0)],
                    "source": macro.get("source", "leader"),
                }
            )
        return rows

    def _profiles_snapshot(self):
        active = str(self.config.data.get("active_profile", "Default"))
        return [
            {"name": name, "active": name == active}
            for name in self.config.list_profiles()
        ]

    def get_state(self, refresh=True):
        accounts = self.logic.scan_slots() if refresh else (self.logic.all_accounts or self.logic.scan_slots())
        return {
            "accounts": self._serialize_accounts(accounts),
            "settings": self._settings_snapshot(),
            "profiles": self._profiles_snapshot(),
            "calibrations": self._calibration_snapshot(),
            "visual_macros": self._visual_macros_snapshot(),
            "activity_log": list(self.activity_log[-60:]),
            "feature_state": self.features.get_status(),
            "app_version": self.app_version,
            "config_path": self.config.path,
            "last_error": self.last_error,
        }

    def save_settings(self, updates):
        touched_profile_keys = False
        for key, value in updates.items():
            if key not in DEFAULT_CONFIG:
                continue
            default_value = DEFAULT_CONFIG[key]
            if isinstance(default_value, bool):
                self.config.data[key] = bool(value)
            elif isinstance(default_value, int):
                self.config.data[key] = int(value)
            elif isinstance(default_value, float):
                self.config.data[key] = float(value)
            else:
                self.config.data[key] = str(value)
            if key in PROFILE_KEYS:
                touched_profile_keys = True

        if "current_mode" in updates:
            self.logic.set_mode(str(self.config.data.get("current_mode", "ALL")))

        if touched_profile_keys:
            self.config.save_profile(self.config.data.get("active_profile", "Default"))

        self.config.save()
        self._append_log("Paramètres sauvegardés.")
        return self.get_state(refresh=False)

    def save_profile(self, payload):
        profile_name = str(payload.get("name", "")).strip()
        saved_name = self.config.save_profile(profile_name)
        self.config.save()
        self._append_log("Profil sauvegardé: %s" % saved_name)
        return self.get_state(refresh=False)

    def apply_profile(self, payload):
        profile_name = str(payload.get("name", "")).strip()
        applied_name = self.config.apply_profile(profile_name)
        self.logic.set_mode(str(self.config.data.get("current_mode", "ALL")))
        self.config.save()
        self._append_log("Profil appliqué: %s" % applied_name)
        return self.get_state(refresh=False)

    def delete_profile(self, payload):
        profile_name = str(payload.get("name", "")).strip()
        active_name = self.config.delete_profile(profile_name)
        self.logic.set_mode(str(self.config.data.get("current_mode", "ALL")))
        self.config.save()
        self._append_log("Profil supprimé: %s" % profile_name)
        state = self.get_state(refresh=False)
        state["active_profile"] = active_name
        return state

    def refresh(self, _payload=None):
        self._append_log("Rafraîchissement manuel.")
        return self.get_state(refresh=True)

    def toggle_account(self, payload):
        self.logic.toggle_account(payload["name"], bool(payload["active"]))
        self._append_log("Compte mis à jour: %s" % payload["name"])
        return self.get_state(refresh=False)

    def set_team(self, payload):
        self.logic.change_team(payload["name"], payload["team"])
        self._append_log("Équipe changée: %s -> %s" % (payload["name"], payload["team"]))
        return self.get_state(refresh=False)

    def set_leader(self, payload):
        self.logic.set_leader(payload["name"])
        self._append_log("Chef défini: %s" % payload["name"])
        return self.get_state(refresh=False)

    def set_initiative(self, payload):
        self.logic.set_account_initiative(payload["name"], payload["initiative"])
        self._append_log("Initiative modifiée: %s" % payload["name"])
        return self.get_state(refresh=False)

    def set_position(self, payload):
        self.logic.set_account_position(payload["name"], int(payload["position"]) - 1)
        self._append_log("Position modifiée: %s" % payload["name"])
        return self.get_state(refresh=False)

    def focus_account(self, payload):
        target_name = payload["name"]
        for account in self.logic.all_accounts or self.logic.scan_slots():
            if account.get("name") == target_name:
                self.logic.focus_window(account.get("hwnd"))
                self._append_log("Focus: %s" % target_name)
                break
        return self.get_state(refresh=False)

    def move_row(self, payload):
        self.logic.move_account(payload["name"], int(payload["direction"]))
        self._append_log("Ordre changé: %s" % payload["name"])
        return self.get_state(refresh=False)

    def close_account(self, payload):
        self.logic.close_account_window(payload["name"])
        self._append_log("Fenêtre fermée: %s" % payload["name"])
        return self.get_state(refresh=True)

    def close_all(self, _payload=None):
        self.logic.close_all_active_accounts()
        self._append_log("Fermeture de la team.")
        return self.get_state(refresh=True)

    def sort_initiative(self, _payload=None):
        sorted_count = self.logic.sort_accounts_by_initiative()
        self._append_log("Tri initiative exécuté.")
        state = self.get_state(refresh=False)
        state["sorted_count"] = sorted_count
        return state

    def scan_initiative(self, _payload=None):
        result = self.logic.execute_scan_initiatives()
        self._append_log("Scan initiative exécuté.")
        state = self.get_state(refresh=False)
        state["scan_result"] = result
        return state

    def invite_group(self, _payload=None):
        self.logic.execute_group_invite()
        self._append_log("Invitation de groupe envoyée.")
        return self.get_state(refresh=False)

    def paste_enter(self, _payload=None):
        self.logic.execute_paste_enter()
        self._append_log("Coller + Entrée exécuté.")
        return self.get_state(refresh=False)

    def auto_zaap(self, _payload=None):
        self.logic.execute_auto_zaap()
        self._append_log("Auto Zaap exécuté.")
        return self.get_state(refresh=False)

    def broadcast_game_key(self, payload):
        config_key = str(payload.get("config_key", ""))
        fallback = str(payload.get("fallback", ""))
        key_name = str(self.config.data.get(config_key, fallback) or fallback)
        if key_name:
            self.logic.broadcast_key(key_name)
            self._append_log("Touche broadcast: %s" % key_name)
        return self.get_state(refresh=False)

    def get_calibrations(self, _payload=None):
        return {"calibrations": self._calibration_snapshot(), "config_path": self.config.path}

    def start_calibration(self, payload):
        calibration_key = str(payload.get("key", ""))
        result = self.features.start_calibration(calibration_key)
        if result.get("started"):
            self._append_log("Calibrage lancé: %s" % calibration_key)
        return {"started": bool(result.get("started")), "message": result.get("message", ""), "assistant": self.features.get_status()}

    def capture_visual_macro(self, payload):
        macro_name = str(payload.get("name", "")).strip()
        button = str(payload.get("button", "left") or "left")
        macro = self.logic.capture_visual_macro(macro_name, button)
        self._append_log("Macro visuelle capturée: %s" % macro_name)
        state = self.get_state(refresh=False)
        state["captured_macro"] = macro
        return state

    def run_visual_macro(self, payload):
        macro_name = str(payload.get("name", "")).strip()
        count = self.logic.run_visual_macro(macro_name)
        self._append_log("Macro visuelle jouée: %s" % macro_name)
        state = self.get_state(refresh=False)
        state["executed_macro_count"] = count
        return state

    def delete_visual_macro(self, payload):
        macro_name = str(payload.get("name", "")).strip()
        self.logic.delete_visual_macro(macro_name)
        self._append_log("Macro visuelle supprimée: %s" % macro_name)
        return self.get_state(refresh=False)

    def shutdown(self, _payload=None):
        self.features.stop()
        self._append_log("Bridge backend arrêté.")
        return {"stopped": True}


def _write_response(response):
    sys.stdout.write(json.dumps(response, ensure_ascii=False) + "\n")
    sys.stdout.flush()


def main():
    bridge = BackendBridge()
    commands = {
        "get_state": lambda payload: bridge.get_state(bool(payload.get("refresh", True))),
        "refresh": bridge.refresh,
        "save_settings": bridge.save_settings,
        "save_profile": bridge.save_profile,
        "apply_profile": bridge.apply_profile,
        "delete_profile": bridge.delete_profile,
        "toggle_account": bridge.toggle_account,
        "set_team": bridge.set_team,
        "set_leader": bridge.set_leader,
        "set_initiative": bridge.set_initiative,
        "set_position": bridge.set_position,
        "focus_account": bridge.focus_account,
        "move_row": bridge.move_row,
        "close_account": bridge.close_account,
        "close_all": bridge.close_all,
        "sort_initiative": bridge.sort_initiative,
        "scan_initiative": bridge.scan_initiative,
        "invite_group": bridge.invite_group,
        "paste_enter": bridge.paste_enter,
        "auto_zaap": bridge.auto_zaap,
        "broadcast_game_key": bridge.broadcast_game_key,
        "get_calibrations": bridge.get_calibrations,
        "start_calibration": bridge.start_calibration,
        "capture_visual_macro": bridge.capture_visual_macro,
        "run_visual_macro": bridge.run_visual_macro,
        "delete_visual_macro": bridge.delete_visual_macro,
        "shutdown": bridge.shutdown,
    }

    for raw_line in sys.stdin:
        raw_line = raw_line.strip()
        if not raw_line:
            continue

        request_id = None
        try:
            request = json.loads(raw_line)
            request_id = request.get("id")
            command = request.get("cmd")
            payload = request.get("payload") or {}
            bridge.last_error = ""

            if command not in commands:
                raise ValueError(f"Commande inconnue: {command}")

            result = commands[command](payload)
            _write_response({"id": request_id, "ok": True, "result": result})
        except Exception as exc:
            logger.exception("Erreur bridge")
            bridge._append_log(str(exc), "error")
            _write_response(
                {
                    "id": request_id,
                    "ok": False,
                    "error": str(exc),
                    "traceback": traceback.format_exc(),
                }
            )


if __name__ == "__main__":
    main()


