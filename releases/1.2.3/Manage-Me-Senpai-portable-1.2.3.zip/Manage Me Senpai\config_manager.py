﻿import copy
import json
import os
import shutil
import sys
import tempfile


PROFILE_KEYS = [
    "accounts_state",
    "accounts_team",
    "account_focus_hotkeys",
    "account_initiatives",
    "classes",
    "custom_order",
    "leader_name",
    "current_mode",
    "macro_positions",
    "visual_macros",
    "volume_level",
    "toolbar_active",
    "toolbar_x",
    "toolbar_y",
    "toolbar_width",
    "toolbar_height",
    "toolbar_layout",
    "show_tooltips",
    "return_to_leader",
    "spam_click_active",
    "auto_group_enabled",
    "auto_trade_enabled",
    "auto_trade_step_delay",
    "auto_trade_color_tolerance",
    "initiative_panel_delay",
    "zaap_delay",
    "click_speed",
    "radial_menu_active",
    "radial_menu_hotkey",
    "compact_mode",
    "ignore_organizer_warning",
    "tutorial_done",
    "prev_key",
    "next_key",
    "leader_key",
    "sync_key",
    "sync_right_key",
    "treasure_key",
    "swap_xp_drop_key",
    "toggle_app_key",
    "paste_enter_key",
    "invite_group_key",
    "auto_zaap_key",
    "refresh_key",
    "sort_taskbar_key",
    "calib_key",
    "game_inv_key",
    "game_char_key",
    "game_spell_key",
    "game_haven_key",
]


DEFAULT_CONFIG = {
    "accounts_state": {},
    "accounts_team": {},
    "account_focus_hotkeys": {},
    "account_initiatives": {},
    "classes": {},
    "custom_order": [],
    "leader_name": "",
    "current_mode": "ALL",
    "macro_positions": {},
    "visual_macros": {},
    "volume_level": 50,
    "toolbar_active": False,
    "toolbar_x": 100,
    "toolbar_y": 100,
    "toolbar_width": 430,
    "toolbar_height": 250,
    "toolbar_layout": "auto",
    "show_tooltips": True,
    "return_to_leader": True,
    "spam_click_active": False,
    "auto_group_enabled": False,
    "auto_trade_enabled": False,
    "auto_trade_step_delay": 0.5,
    "auto_trade_color_tolerance": 48,
    "initiative_panel_delay": 0.45,
    "zaap_delay": "1.8",
    "click_speed": "Lent",
    "radial_menu_active": True,
    "radial_menu_hotkey": "alt+left_click",
    "compact_mode": False,
    "ignore_organizer_warning": False,
    "tutorial_done": False,
    "prev_key": "",
    "next_key": "",
    "leader_key": "",
    "sync_key": "",
    "sync_right_key": "",
    "treasure_key": "",
    "swap_xp_drop_key": "",
    "toggle_app_key": "",
    "paste_enter_key": "",
    "invite_group_key": "",
    "auto_zaap_key": "",
    "refresh_key": "",
    "sort_taskbar_key": "",
    "calib_key": "f4",
    "game_inv_key": "i",
    "game_char_key": "c",
    "game_spell_key": "s",
    "game_haven_key": "h",
    "profiles": {},
    "active_profile": "Default",
    "update_manifest_url": "https://api.github.com/repos/WilliamFerrant/manage-me-senpai-manifest/contents/update-manifest.json?ref=main",
    "update_channel": "stable",
    "last_update_check_utc": "",
}


class Config:
    def __init__(self, path=None):
        self.path = path or self._get_default_path()
        self._migrate_legacy_settings_if_needed()
        self.data = self._load()
        self._ensure_profiles()

    def _get_default_path(self):
        if getattr(sys, "frozen", False):
            appdata_dir = os.environ.get("APPDATA") or os.environ.get("LOCALAPPDATA")
            if appdata_dir:
                return os.path.join(appdata_dir, "ManageMeSenpai", "settings.json")

            home_dir = os.path.expanduser("~")
            return os.path.join(home_dir, "AppData", "Roaming", "ManageMeSenpai", "settings.json")

        base_dir = os.path.dirname(os.path.abspath(__file__))
        return os.path.join(base_dir, "settings.json")

    def _migrate_legacy_settings_if_needed(self):
        if os.path.exists(self.path):
            return

        legacy_candidates = []

        if getattr(sys, "frozen", False):
            exe_dir = os.path.dirname(sys.executable)
            legacy_candidates.append(os.path.join(exe_dir, "settings.json"))

        module_dir = os.path.dirname(os.path.abspath(__file__))
        legacy_candidates.append(os.path.join(module_dir, "settings.json"))
        legacy_candidates.append(os.path.join(os.getcwd(), "settings.json"))

        seen = set()
        for candidate in legacy_candidates:
            candidate = os.path.abspath(candidate)
            if candidate == os.path.abspath(self.path) or candidate in seen:
                continue
            seen.add(candidate)

            if not os.path.exists(candidate):
                continue

            try:
                os.makedirs(os.path.dirname(self.path), exist_ok=True)
                shutil.copy2(candidate, self.path)
                return
            except OSError:
                continue

    def _load(self):
        data = copy.deepcopy(DEFAULT_CONFIG)
        if os.path.exists(self.path):
            try:
                with open(self.path, "r", encoding="utf-8") as handle:
                    loaded = json.load(handle)
                if isinstance(loaded, dict):
                    self._deep_update(data, loaded)
            except (OSError, json.JSONDecodeError):
                pass
        return data

    def _deep_update(self, base, updates):
        for key, value in updates.items():
            if key in base and isinstance(base[key], dict) and isinstance(value, dict):
                self._deep_update(base[key], value)
            else:
                base[key] = value

    def _ensure_profiles(self):
        profiles = self.data.get("profiles")
        if not isinstance(profiles, dict):
            profiles = {}

        normalized = {}
        for name, values in profiles.items():
            profile_name = str(name).strip()
            if not profile_name:
                continue
            normalized[profile_name] = self._normalized_profile(values)

        if not normalized:
            normalized["Default"] = self.snapshot_profile()

        active_profile = str(self.data.get("active_profile") or "").strip() or "Default"
        if active_profile not in normalized:
            active_profile = sorted(normalized.keys())[0]

        self.data["profiles"] = normalized
        self.data["active_profile"] = active_profile

    def _normalized_profile(self, values):
        profile = {}
        source = values if isinstance(values, dict) else {}
        for key in PROFILE_KEYS:
            profile[key] = copy.deepcopy(source.get(key, self.data.get(key, DEFAULT_CONFIG.get(key))))
        return profile

    def snapshot_profile(self):
        snapshot = {}
        for key in PROFILE_KEYS:
            snapshot[key] = copy.deepcopy(self.data.get(key, DEFAULT_CONFIG.get(key)))
        return snapshot

    def save_profile(self, name):
        profile_name = str(name or "").strip()
        if not profile_name:
            raise ValueError("Nom de profil invalide.")
        self._ensure_profiles()
        self.data["profiles"][profile_name] = self.snapshot_profile()
        self.data["active_profile"] = profile_name
        return profile_name

    def apply_profile(self, name):
        profile_name = str(name or "").strip()
        self._ensure_profiles()
        if profile_name not in self.data["profiles"]:
            raise ValueError("Profil introuvable.")
        profile = self._normalized_profile(self.data["profiles"][profile_name])
        for key in PROFILE_KEYS:
            self.data[key] = copy.deepcopy(profile.get(key, DEFAULT_CONFIG.get(key)))
        self.data["active_profile"] = profile_name
        self.data["profiles"][profile_name] = self.snapshot_profile()
        return profile_name

    def delete_profile(self, name):
        profile_name = str(name or "").strip()
        self._ensure_profiles()
        if profile_name not in self.data["profiles"]:
            raise ValueError("Profil introuvable.")
        if len(self.data["profiles"]) <= 1:
            raise ValueError("Impossible de supprimer le dernier profil.")

        del self.data["profiles"][profile_name]

        if self.data.get("active_profile") == profile_name:
            next_profile = sorted(self.data["profiles"].keys())[0]
            self.apply_profile(next_profile)
        return self.data.get("active_profile", "Default")

    def list_profiles(self):
        self._ensure_profiles()
        return sorted(self.data["profiles"].keys(), key=str.casefold)

    def save(self):
        directory = os.path.dirname(self.path)
        if directory:
            os.makedirs(directory, exist_ok=True)

        fd, temp_path = tempfile.mkstemp(prefix="settings_", suffix=".json", dir=directory or None)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump(self.data, handle, indent=2, ensure_ascii=False)
                handle.write("\n")
            os.replace(temp_path, self.path)
        except OSError:
            try:
                os.remove(temp_path)
            except OSError:
                pass
            raise

    def reset(self):
        self.data = copy.deepcopy(DEFAULT_CONFIG)
        self._ensure_profiles()
        self.save()





