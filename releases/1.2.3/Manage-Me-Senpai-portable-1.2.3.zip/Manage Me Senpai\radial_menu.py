import math
import tkinter as tk


class RadialMenu:
    def __init__(self, root, on_select, accent_color="#6f8fb3"):
        self.root = root
        self.on_select = on_select
        self.accent_color = accent_color
        self.base_volume = 0.5
        self.window = tk.Toplevel(root)
        self.window.withdraw()
        self.window.overrideredirect(True)
        self.window.attributes("-topmost", True)
        self.window.configure(bg="#111111")

        self.canvas_size = 320
        self.center = self.canvas_size // 2
        self.outer_radius = 118
        self.inner_radius = 48
        self.deadzone = 22
        self.hover_name = None
        self.current_name = None
        self.accounts = []
        self.center_screen = (0, 0)
        self.segment_bounds = []
        self.segment_ids = []
        self.label_ids = []
        self.title_id = None
        self.hint_id = None

        self.canvas = tk.Canvas(
            self.window,
            width=self.canvas_size,
            height=self.canvas_size,
            bg="#111111",
            highlightthickness=0,
            bd=0,
        )
        self.canvas.pack()

    def set_base_volume(self, volume):
        try:
            self.base_volume = max(0.0, min(1.0, float(volume)))
        except (TypeError, ValueError):
            self.base_volume = 0.5

    def show(self, x, y, accounts, current_name=None):
        self.accounts = list(accounts or [])
        self.current_name = current_name
        self.hover_name = None
        self.center_screen = (int(x), int(y))
        offset_x = x - self.center
        offset_y = y - self.center
        self.window.geometry(f"{self.canvas_size}x{self.canvas_size}+{offset_x}+{offset_y}")
        self._redraw()
        self.window.deiconify()
        self.window.lift()

    def hide(self):
        self.window.withdraw()

    def update_pointer(self, x, y):
        new_hover = self.get_target_at_point(x, y)
        if new_hover != self.hover_name:
            self.hover_name = new_hover
            self._redraw()

    def get_target_at_point(self, x, y):
        if not self.accounts:
            return None

        dx = x - self.center_screen[0]
        dy = y - self.center_screen[1]
        distance = math.hypot(dx, dy)
        if distance < self.inner_radius - self.deadzone or distance > self.outer_radius + 18:
            return None

        angle = (math.degrees(math.atan2(dy, dx)) + 90) % 360
        for start, extent, name in self.segment_bounds:
            end = (start + extent) % 360
            if extent >= 360:
                return name
            if start <= end:
                if start <= angle < end:
                    return name
            else:
                if angle >= start or angle < end:
                    return name
        return None

    def _redraw(self):
        self.canvas.delete("all")
        self.segment_bounds = []
        self.segment_ids = []
        self.label_ids = []

        self.canvas.create_oval(
            10,
            10,
            self.canvas_size - 10,
            self.canvas_size - 10,
            fill="#171717",
            outline="#2b2b2b",
            width=1,
        )

        if not self.accounts:
            self.canvas.create_text(
                self.center,
                self.center,
                text="Aucun perso actif",
                fill="#d0d0d0",
                font=("Segoe UI", 12, "bold"),
            )
            return

        count = len(self.accounts)
        extent = 360 / count
        start_offset = -extent / 2

        for index, account in enumerate(self.accounts):
            name = account.get("name", "Inconnu")
            start = (index * extent + start_offset) % 360
            is_hover = name == self.hover_name
            is_current = name == self.current_name
            fill = "#2a2a2a"
            outline = "#3b3b3b"
            text_fill = "#d0d0d0"

            if is_current:
                fill = "#314258"
                outline = "#6f8fb3"
            if is_hover:
                fill = self.accent_color
                outline = "#b7d1ef"
                text_fill = "#f7f8fa"

            tk_start = (90 - start) % 360
            segment = self.canvas.create_arc(
                self.center - self.outer_radius,
                self.center - self.outer_radius,
                self.center + self.outer_radius,
                self.center + self.outer_radius,
                start=tk_start,
                extent=-extent,
                fill=fill,
                outline=outline,
                style=tk.PIESLICE,
                width=2,
            )
            self.segment_ids.append(segment)
            self.segment_bounds.append((start % 360, extent, name))

            label_angle = math.radians(start + extent / 2 - 90)
            label_radius = (self.outer_radius + self.inner_radius) / 2
            lx = self.center + math.cos(label_angle) * label_radius
            ly = self.center + math.sin(label_angle) * label_radius
            label = self.canvas.create_text(
                lx,
                ly,
                text=self._shorten(name),
                fill=text_fill,
                font=("Segoe UI", 10, "bold" if is_hover or is_current else "normal"),
                width=76,
                justify="center",
            )
            self.label_ids.append(label)

        self.canvas.create_oval(
            self.center - self.inner_radius,
            self.center - self.inner_radius,
            self.center + self.inner_radius,
            self.center + self.inner_radius,
            fill="#1e1e1e",
            outline="#3b3b3b",
            width=2,
        )
        self.canvas.create_text(
            self.center,
            self.center - 8,
            text="Manage Me",
            fill="#d0d0d0",
            font=("Segoe UI", 11, "bold"),
        )
        self.canvas.create_text(
            self.center,
            self.center + 12,
            text=self.hover_name or "Relâche pour choisir",
            fill="#9aa0a6",
            font=("Segoe UI", 9),
            width=90,
            justify="center",
        )

    def _shorten(self, text, limit=12):
        if len(text) <= limit:
            return text
        return text[: limit - 1] + "…"
