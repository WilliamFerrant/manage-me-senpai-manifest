import logging
import os
import sys
import queue
import threading
import time
import tkinter as tk
from datetime import datetime

import keyboard
import win32api
import win32con
import win32gui
from PIL import ImageGrab

from constants import AZERTY_TO_SCAN
from radial_menu import RadialMenu


logger = logging.getLogger("ManageMeSenpai.Features")


BG_ROOT = "#141414"
BG_PANEL = "#202020"
BG_CARD = "#262626"
BG_HOVER = "#313131"
BORDER = "#404040"
ACCENT = "#6f8fb3"
TEXT = "#f0f0f0"
TEXT_MUTED = "#b8bec8"
SUCCESS = "#8fd19e"
WARNING = "#f2d479"
ERROR = "#d17b7b"

CALIBRATION_TITLES = {
    "chat_position": "Chat",
    "initiative_region": "Zone initiative",
    "xp_drop_button": "Bouton XP / Drop",
    "zaaps": "Zaaps",
    "game_zone": "Zone de jeu",
    "map_coords": "Coordonnees",
    "map_borders": "Bords de map",
    "group_accept_pos": "Acceptation de groupe",
    "trade_notif_pos": "Notification echange",
    "trade_notif_pos2": "Pixel anti faux positif",
    "trade_validate_pos": "Pixel vert valider",
    "trade_validate_click_pos": "Bouton valider",
}

def configure_tk_runtime():
    candidates = []
    for raw_root in [sys.base_prefix, os.path.dirname(sys.executable), os.path.dirname(getattr(sys, "_base_executable", ""))]:
        if not raw_root:
            continue
        candidates.append(raw_root)
        candidates.append(os.path.join(raw_root, "tcl"))

    seen = set()
    for root in candidates:
        root = os.path.abspath(root)
        if root in seen:
            continue
        seen.add(root)
        tcl_dir = os.path.join(root, "tcl8.6")
        tk_dir = os.path.join(root, "tk8.6")
        if os.path.exists(os.path.join(tcl_dir, "init.tcl")) and os.path.exists(os.path.join(tk_dir, "tk.tcl")):
            os.environ["TCL_LIBRARY"] = tcl_dir
            os.environ["TK_LIBRARY"] = tk_dir
            return True
    return False


def normalize_hotkey_string(hotkey):
    if not hotkey:
        return ""

    aliases = {
        "click": "left_click",
        "leftclick": "left_click",
        "left_click": "left_click",
        "left click": "left_click",
        "clic": "left_click",
        "clic_gauche": "left_click",
        "clic gauche": "left_click",
        "rightclick": "right_click",
        "right_click": "right_click",
        "right click": "right_click",
        "clic_droit": "right_click",
        "clic droit": "right_click",
        "middleclick": "middle_click",
        "middle_click": "middle_click",
        "middle click": "middle_click",
        "clic_milieu": "middle_click",
        "clic milieu": "middle_click",
        "maj": "shift",
        "control": "ctrl",
        "grave": "`",
        "backtick": "`",
        "ù": "`",
    }

    normalized_parts = []
    for raw_part in str(hotkey).split("+"):
        part = raw_part.strip().lower()
        if not part:
            continue
        normalized_parts.append(aliases.get(part, part))
    return "+".join(normalized_parts)


class OverlayWindow:
    def __init__(self, service, root):
        self.service = service
        self.root = root
        self.visible = False
        self._drag_offset = (0, 0)

        self.window = tk.Toplevel(root)
        self.window.withdraw()
        self.window.overrideredirect(True)
        self.window.attributes("-topmost", True)
        self.window.attributes("-alpha", 0.95)
        self.window.configure(bg=BG_ROOT)
        self.window.geometry(
            "+{0}+{1}".format(
                int(self.service.config.data.get("toolbar_x", 100)),
                int(self.service.config.data.get("toolbar_y", 100)),
            )
        )

        title = tk.Frame(self.window, bg=BG_ROOT, highlightbackground=BORDER, highlightthickness=1)
        title.pack(fill="x")
        title.bind("<Button-1>", self.start_move)
        title.bind("<B1-Motion>", self.do_move)
        title.bind("<ButtonRelease-1>", self.stop_move)

        title_label = tk.Label(
            title,
            text="Manage Me Senpai Overlay",
            bg=BG_ROOT,
            fg=TEXT,
            font=("Segoe UI", 9, "bold"),
            padx=10,
            pady=6,
            cursor="fleur",
        )
        title_label.pack(side="left")
        title_label.bind("<Button-1>", self.start_move)
        title_label.bind("<B1-Motion>", self.do_move)
        title_label.bind("<ButtonRelease-1>", self.stop_move)

        close_btn = tk.Button(
            title,
            text="×",
            command=self.disable_overlay,
            bg=BG_ROOT,
            fg=TEXT_MUTED,
            activebackground=BG_HOVER,
            activeforeground=TEXT,
            bd=0,
            padx=8,
            pady=4,
            highlightthickness=0,
            relief="flat",
            font=("Segoe UI", 10, "bold"),
        )
        close_btn.pack(side="right", padx=2)

        content = tk.Frame(self.window, bg=BG_PANEL, highlightbackground=BORDER, highlightthickness=1)
        content.pack(fill="both", expand=True)

        active_card = tk.Frame(content, bg=BG_CARD, highlightbackground=BORDER, highlightthickness=1)
        active_card.pack(fill="x", padx=8, pady=(8, 6))

        tk.Label(
            active_card,
            text="FOCUS",
            bg=BG_CARD,
            fg=TEXT_MUTED,
            font=("Segoe UI", 8, "bold"),
            anchor="w",
        ).pack(fill="x", padx=10, pady=(8, 0))
        self.active_value = tk.Label(
            active_card,
            text="Aucun perso",
            bg=BG_CARD,
            fg=TEXT,
            font=("Segoe UI", 11, "bold"),
            anchor="w",
        )
        self.active_value.pack(fill="x", padx=10, pady=(2, 8))

        top_row = tk.Frame(content, bg=BG_PANEL)
        top_row.pack(fill="x", padx=8, pady=(0, 6))

        tk.Label(top_row, text="Mode", bg=BG_PANEL, fg=TEXT_MUTED, font=("Segoe UI", 9, "bold")).pack(side="left", padx=(0, 6))
        self.mode_var = tk.StringVar(value=self.service.config.data.get("current_mode", "ALL"))
        self.mode_menu = tk.OptionMenu(top_row, self.mode_var, "ALL", "Team 1", "Team 2", command=self.change_mode)
        self.mode_menu.configure(
            bg=BG_CARD,
            fg=TEXT,
            activebackground=BG_HOVER,
            activeforeground=TEXT,
            highlightthickness=1,
            highlightbackground=BORDER,
            bd=0,
            relief="flat",
            font=("Segoe UI", 9),
            width=8,
        )
        self.mode_menu["menu"].configure(bg=BG_CARD, fg=TEXT, activebackground=ACCENT, activeforeground="#ffffff")
        self.mode_menu.pack(side="left")

        action_row = tk.Frame(content, bg=BG_PANEL)
        action_row.pack(fill="x", padx=8, pady=(0, 6))
        self._make_button(action_row, "Inviter", self._invite_group).pack(side="left", padx=(0, 6))
        self._make_button(action_row, "Coller", self._paste_enter).pack(side="left", padx=(0, 6))
        self._make_button(action_row, "Refresh", self._refresh_accounts).pack(side="left")

        game_row = tk.Frame(content, bg=BG_PANEL)
        game_row.pack(fill="x", padx=8, pady=(0, 8))
        self._make_button(game_row, "Inv", lambda: self._broadcast("game_inv_key", "i")).pack(side="left", padx=(0, 6))
        self._make_button(game_row, "Carac", lambda: self._broadcast("game_char_key", "c")).pack(side="left", padx=(0, 6))
        self._make_button(game_row, "Sorts", lambda: self._broadcast("game_spell_key", "s")).pack(side="left", padx=(0, 6))
        self._make_button(game_row, "H-Sac", lambda: self._broadcast("game_haven_key", "h")).pack(side="left", padx=(0, 6))
        self._make_button(game_row, "Zaap", self._auto_zaap).pack(side="left")

    def _make_button(self, parent, text, command):
        return tk.Button(
            parent,
            text=text,
            command=command,
            bg=BG_CARD,
            fg=TEXT,
            activebackground=ACCENT,
            activeforeground="#ffffff",
            highlightbackground=BORDER,
            highlightthickness=1,
            relief="flat",
            bd=0,
            padx=10,
            pady=6,
            font=("Segoe UI", 9, "bold"),
            cursor="hand2",
        )

    def _run_async(self, func):
        thread = threading.Thread(target=func, daemon=True)
        thread.start()

    def _broadcast(self, config_key, fallback_key):
        key_name = self.service.config.data.get(config_key, fallback_key)
        self._run_async(lambda: self.service.logic.broadcast_key(key_name))

    def _auto_zaap(self):
        self._run_async(self.service.logic.execute_auto_zaap)

    def _paste_enter(self):
        self._run_async(self.service.logic.execute_paste_enter)

    def _invite_group(self):
        self._run_async(self.service.logic.execute_group_invite)

    def _refresh_accounts(self):
        self._run_async(self.service.logic.scan_slots)

    def disable_overlay(self):
        self.service.config.data["toolbar_active"] = False
        self.service.config.save()
        self.hide()

    def change_mode(self, choice):
        self.service.logic.set_mode(choice)
        self.service.config.data["current_mode"] = choice
        self.service.config.save()

    def sync_from_config(self):
        desired = self.service.config.data.get("current_mode", "ALL")
        if self.mode_var.get() != desired:
            self.mode_var.set(desired)

    def update_active_account(self, account):
        if not account:
            self.active_value.configure(text="Aucun perso")
            return

        classe = account.get("classe") or ""
        name = account.get("name") or "Inconnu"
        display = name if not classe or classe == "Inconnu" else "{0} · {1}".format(name, classe)
        self.active_value.configure(text=display)

    def show(self):
        if self.visible:
            return
        self.visible = True
        self.window.deiconify()
        self.window.lift()

    def hide(self):
        if not self.visible:
            return
        self.visible = False
        self.window.withdraw()

    def start_move(self, event):
        self._drag_offset = (event.x_root - self.window.winfo_x(), event.y_root - self.window.winfo_y())

    def do_move(self, event):
        offset_x, offset_y = self._drag_offset
        self.window.geometry("+{0}+{1}".format(event.x_root - offset_x, event.y_root - offset_y))

    def stop_move(self, _event):
        self.service.config.data["toolbar_x"] = self.window.winfo_x()
        self.service.config.data["toolbar_y"] = self.window.winfo_y()
        self.service.config.save()


class FeatureService:
    def __init__(self, config, logic, error_callback=None):
        self.config = config
        self.logic = logic
        self.error_callback = error_callback
        self._ui_thread = None
        self._monitor_thread = None
        self._stop_event = threading.Event()
        self._ready_event = threading.Event()
        self._queue = queue.Queue()
        self._root = None
        self._tooltip = None
        self._tooltip_label = None
        self._overlay = None
        self._radial = None
        self._ui_available = False
        self._is_calibrating = False
        self._radial_was_open = False
        self._last_overlay_hwnd = object()
        self._calibration_status = {
            "active": False,
            "key": "",
            "title": "",
            "message": "Aucun calibrage en cours.",
            "last_result": "",
            "updated_at": "",
        }

    def start(self):
        if self._ui_thread and self._ui_thread.is_alive():
            return
        self._stop_event.clear()
        self._ready_event.clear()
        self._ui_thread = threading.Thread(target=self._ui_loop, name="MMS-FeatureUI", daemon=True)
        self._ui_thread.start()
        self._ready_event.wait(5)
        if not self._ui_available:
            return
        self._monitor_thread = threading.Thread(target=self._monitor_loop, name="MMS-FeatureMonitor", daemon=True)
        self._monitor_thread.start()
        self.sync_settings()
    def stop(self):
        self._stop_event.set()
        if self._root is not None:
            self.post(self._root.destroy)

    def post(self, func, *args, **kwargs):
        self._queue.put((func, args, kwargs))

    def sync_settings(self):
        self.post(self._sync_settings_ui)

    def get_status(self):
        status = dict(self._calibration_status)
        status["ui_available"] = bool(self._ui_available)
        status["overlay_enabled"] = bool(self.config.data.get("toolbar_active", False))
        status["radial_enabled"] = bool(self.config.data.get("radial_menu_active", True))
        status["toolbar_layout"] = str(self.config.data.get("toolbar_layout", "auto"))
        return status

    def _update_calibration_status(self, active=None, key=None, title=None, message=None, last_result=None):
        if active is not None:
            self._calibration_status["active"] = bool(active)
        if key is not None:
            self._calibration_status["key"] = str(key or "")
        if title is not None:
            self._calibration_status["title"] = str(title or "")
        if message is not None:
            self._calibration_status["message"] = str(message or "")
        if last_result is not None:
            self._calibration_status["last_result"] = str(last_result or "")
        self._calibration_status["updated_at"] = datetime.utcnow().strftime("%H:%M:%S")

    def start_calibration(self, key):
        mapping = {
            "chat_position": self.start_calib_chat,
            "initiative_region": self.start_calib_initiative_region,
            "xp_drop_button": self.start_calib_xp_drop,
            "zaaps": self.start_calib_zaap,
            "game_zone": self.start_calib_zone_jeu,
            "map_coords": self.start_calib_coord,
            "map_borders": self.start_calib_map_borders,
            "group_accept_pos": self.start_calib_group_accept,
            "trade_notif_pos": self.start_calib_trade_notif,
            "trade_notif_pos2": self.start_calib_trade_notif2,
            "trade_validate_pos": self.start_calib_trade_validate,
            "trade_validate_click_pos": self.start_calib_trade_validate_click,
        }
        handler = mapping.get(key)
        if handler is None:
            raise ValueError("Calibrage inconnu: {0}".format(key))
        self._update_calibration_status(True, key, CALIBRATION_TITLES.get(key, key), "Initialisation du workflow de calibrage...", "")
        return handler()
    def _ui_loop(self):
        try:
            configure_tk_runtime()
            self._root = tk.Tk()
            self._root.withdraw()
            self._root.configure(bg=BG_ROOT)

            self._tooltip = tk.Toplevel(self._root)
            self._tooltip.withdraw()
            self._tooltip.overrideredirect(True)
            self._tooltip.attributes("-topmost", True)
            self._tooltip.configure(bg=BG_ROOT)
            self._tooltip_label = tk.Label(
                self._tooltip,
                text="",
                justify="left",
                bg=BG_ROOT,
                fg=TEXT,
                padx=12,
                pady=10,
                font=("Segoe UI", 9, "bold"),
                highlightbackground=BORDER,
                highlightthickness=1,
            )
            self._tooltip_label.pack()

            self._overlay = OverlayWindow(self, self._root)
            self._radial = RadialMenu(self._root, self.on_radial_focus_select, accent_color=ACCENT)
            self._radial.set_base_volume(self.config.data.get("volume_level", 50) / 100.0)
            self._ui_available = True
            self._ready_event.set()
            self._root.after(30, self._pump_queue)
            self._root.after(30, self._tooltip_tick)
            self._root.mainloop()
        except Exception:
            self._ui_available = False
            logger.exception("Impossible de demarrer le runtime Tk des features")
            self._ready_event.set()

    def _pump_queue(self):
        while True:
            try:
                func, args, kwargs = self._queue.get_nowait()
            except queue.Empty:
                break

            try:
                func(*args, **kwargs)
            except Exception:
                logger.exception("Erreur UI feature")

        if not self._stop_event.is_set() and self._root is not None:
            self._root.after(30, self._pump_queue)

    def _tooltip_tick(self):
        if self._is_calibrating and self._tooltip is not None:
            try:
                x, y = win32api.GetCursorPos()
                self._tooltip.geometry("+{0}+{1}".format(x + 18, y + 18))
                self._tooltip.lift()
            except Exception:
                pass

        if not self._stop_event.is_set() and self._root is not None:
            self._root.after(30, self._tooltip_tick)

    def _sync_settings_ui(self):
        if self._overlay is None or self._radial is None:
            return
        self._overlay.sync_from_config()
        self._radial.set_base_volume(self.config.data.get("volume_level", 50) / 100.0)
        if self.config.data.get("toolbar_active", False):
            self._overlay.show()
        else:
            self._overlay.hide()

    def _monitor_loop(self):
        while not self._stop_event.is_set():
            try:
                self._tick_overlay_state()
                self._tick_radial_state()
            except Exception:
                logger.exception("Erreur monitor feature")
            time.sleep(0.06)

    def _tick_overlay_state(self):
        if not self._ui_available or self._overlay is None:
            return
        if self.config.data.get("toolbar_active", False):
            self.post(self._overlay.show)
        else:
            self.post(self._overlay.hide)

        active_account = None
        fg_hwnd = win32gui.GetForegroundWindow()
        for account in self.logic.get_cycle_list():
            if account.get("hwnd") == fg_hwnd:
                active_account = account
                break

        if fg_hwnd != self._last_overlay_hwnd:
            self._last_overlay_hwnd = fg_hwnd
            self.post(self._overlay.update_active_account, active_account)
            self.post(self._overlay.sync_from_config)

    def _tick_radial_state(self):
        if not self._ui_available or self._radial is None:
            return
        radial_hotkey = normalize_hotkey_string(self.config.data.get("radial_menu_hotkey", ""))
        radial_active = self.config.data.get("radial_menu_active", True)

        if not radial_active or not radial_hotkey:
            if self._radial_was_open:
                self._radial_was_open = False
                self.post(self._radial.hide)
            return

        is_pressed = self.is_hotkey_pressed(radial_hotkey)
        if is_pressed and not self._radial_was_open:
            self._radial_was_open = True
            active_accounts = [
                {"name": acc.get("name"), "classe": acc.get("classe", "Inconnu"), "hwnd": acc.get("hwnd")}
                for acc in self.logic.get_cycle_list()
            ]
            fg_hwnd = win32gui.GetForegroundWindow()
            current_name = None
            for account in active_accounts:
                if account.get("hwnd") == fg_hwnd:
                    current_name = account.get("name")
                    break
            x, y = win32api.GetCursorPos()
            self.post(self._radial.show, x, y, active_accounts, current_name)
        elif self._radial_was_open and is_pressed:
            x, y = win32api.GetCursorPos()
            self.post(self._radial.update_pointer, x, y)
        elif self._radial_was_open and not is_pressed:
            self._radial_was_open = False
            x, y = win32api.GetCursorPos()
            target_name = self._radial.get_target_at_point(x, y)
            self.post(self._radial.hide)
            if target_name:
                threading.Thread(target=self.on_radial_focus_select, args=(target_name,), daemon=True).start()

    def on_radial_focus_select(self, target_name):
        for account in self.logic.all_accounts:
            if account.get("name") == target_name:
                self.logic.focus_window(account.get("hwnd"))
                return

    def get_vk(self, key_str):
        key_str = normalize_hotkey_string(key_str)
        mapping = {
            "alt": win32con.VK_MENU,
            "ctrl": win32con.VK_CONTROL,
            "shift": win32con.VK_SHIFT,
            "left_click": 0x01,
            "right_click": 0x02,
            "middle_click": 0x04,
            "mouse4": 0x05,
            "mouse5": 0x06,
            "space": 0x20,
            "enter": 0x0D,
            "insert": 0x2D,
            "home": 0x24,
            "end": 0x23,
            "pageup": 0x21,
            "pagedown": 0x22,
            "up": 0x26,
            "down": 0x28,
            "left": 0x25,
            "right": 0x27,
        }
        if key_str in mapping:
            return mapping[key_str]

        scan_code = AZERTY_TO_SCAN.get(key_str)
        if scan_code is not None:
            vk = win32api.MapVirtualKey(scan_code, 1)
            if vk:
                return vk

        if len(key_str) == 1:
            return ord(key_str.upper())
        if key_str.startswith("f") and key_str[1:].isdigit():
            return 0x6F + int(key_str[1:])
        return None
    def is_hotkey_pressed(self, hotkey_string):
        hotkey_string = normalize_hotkey_string(hotkey_string)
        if not hotkey_string:
            return False
        parts = hotkey_string.split("+")
        for part in parts:
            vk = self.get_vk(part.strip())
            if not vk or win32api.GetAsyncKeyState(vk) >= 0:
                return False
        return True

    def show_tooltip(self, text, color=TEXT):
        if self._is_calibrating:
            self._update_calibration_status(message=text)
        if not self._ui_available:
            return
        self.post(self._show_tooltip_ui, text, color)
    def _show_tooltip_ui(self, text, color):
        self._tooltip_label.configure(text=text, fg=color)
        try:
            x, y = win32api.GetCursorPos()
            self._tooltip.geometry("+{0}+{1}".format(x + 18, y + 18))
        except Exception:
            pass
        self._tooltip.deiconify()
        self._tooltip.lift()

    def hide_tooltip(self):
        if not self._ui_available:
            return
        self.post(self._hide_tooltip_ui)

    def _hide_tooltip_ui(self):
        if self._tooltip is not None:
            self._tooltip.withdraw()

    def show_message(self, text, color=SUCCESS, duration_ms=2200):
        if self._is_calibrating:
            self._update_calibration_status(message=text, last_result=text)
        if not self._ui_available:
            return
        self.post(self._show_message_ui, text, color, duration_ms)
    def _show_message_ui(self, text, color, duration_ms):
        self._show_tooltip_ui(text, color)
        if self._root is not None:
            self._root.after(duration_ms, self._hide_tooltip_ui)

    def _report_error(self, message):
        if self.error_callback:
            try:
                self.error_callback(message)
            except Exception:
                logger.exception("Erreur callback")

    def wait_for_calib_or_esc(self):
        calib_key = normalize_hotkey_string(self.config.data.get("calib_key", "f4") or "f4")
        while True:
            event = keyboard.read_event(suppress=True)
            if event.event_type != keyboard.KEY_DOWN:
                continue
            if event.name == calib_key:
                return True
            if event.name == "esc":
                return False

    def _resolve_calibration_hwnd(self, message="Aucune fenêtre Dofus détectée pour calibrer."):
        hwnd = self.logic.get_calibration_target_hwnd()
        if hwnd:
            return hwnd
        self._report_error(message)
        self.show_message("❌ {0}".format(message), ERROR)
        return None

    def _capture_calibration_point(self, hwnd, label):
        pos = self.logic.get_relative_ratio_pos(hwnd)
        if pos:
            return pos
        msg = "Impossible de capturer {0}. Place la souris dans la fenêtre Dofus ciblée.".format(label)
        self._report_error(msg)
        self.show_message("❌ {0}".format(msg), ERROR)
        return None

    def _capture_calibration_region(self, hwnd, top_left, bot_right, label, min_width=8, min_height=8):
        region = [
            min(top_left[0], bot_right[0]),
            min(top_left[1], bot_right[1]),
            max(top_left[0], bot_right[0]),
            max(top_left[1], bot_right[1]),
        ]
        bbox = self.logic.get_screen_bbox_from_saved(hwnd, region)
        if not bbox:
            msg = "{0} invalide. Recommence en restant dans la fenêtre Dofus.".format(label)
            self._report_error(msg)
            self.show_message("❌ {0}".format(msg), ERROR)
            return None

        width = bbox[2] - bbox[0]
        height = bbox[3] - bbox[1]
        if width < min_width or height < min_height:
            msg = "{0} trop petite ({1}x{2}px). Recalibre plus large.".format(label, width, height)
            self._report_error(msg)
            self.show_message("❌ {0}".format(msg), ERROR)
            return None
        return region

    def _sample_color(self, hwnd, pos):
        coords = self.logic.get_screen_coords_from_saved(hwnd, pos) if pos else None
        if not coords:
            return None
        x, y = coords
        img = ImageGrab.grab(bbox=(x, y, x + 1, y + 1))
        return img.getpixel((0, 0))[:3]

    def _start_worker(self, worker):
        if self._is_calibrating:
            return {"started": False, "message": "Un calibrage est déjà en cours."}
        self._is_calibrating = True
        threading.Thread(target=worker, daemon=True).start()
        return {"started": True, "assistant": self.get_status()}

    def _end_calibration(self):
        self._is_calibrating = False
        self._update_calibration_status(active=False)
        self.hide_tooltip()
    def start_calib_chat(self):
        target_hwnd = self._resolve_calibration_hwnd()
        if not target_hwnd:
            return {"started": False}
        self.logic.focus_window(target_hwnd)
        time.sleep(0.2)
        key_name = (self.config.data.get("calib_key", "F4") or "F4").upper()
        self.show_tooltip("Clique dans le chat Dofus, puis appuie sur {0} pour mémoriser la position.\n(Echap pour annuler)".format(key_name), WARNING)

        def worker():
            try:
                if self.wait_for_calib_or_esc():
                    pos = self._capture_calibration_point(target_hwnd, "la position du chat")
                    if pos:
                        self.config.data.setdefault("macro_positions", {})["chat_position"] = list(pos)
                        self.config.save()
                        self.show_message("✅ Chat calibré.", SUCCESS)
            finally:
                self._end_calibration()

        return self._start_worker(worker)

    def start_calib_initiative_region(self):
        target_hwnd = self._resolve_calibration_hwnd()
        if not target_hwnd:
            return {"started": False}
        self.logic.focus_window(target_hwnd)
        time.sleep(0.2)
        key_name = (self.config.data.get("calib_key", "F4") or "F4").upper()
        self.show_tooltip(
            "Ouvre les caractéristiques du perso. Place la souris en haut-gauche du nombre Initiative puis {0}.\nEnsuite place-la en bas-droite puis {0}.\n(Echap pour annuler)".format(key_name),
            WARNING,
        )

        def worker():
            try:
                if not self.wait_for_calib_or_esc():
                    self.show_message("❌ Calibration initiative annulée.", WARNING)
                    return
                top_left = self._capture_calibration_point(target_hwnd, "le coin haut-gauche de l'initiative")
                if not top_left:
                    return
                self.show_tooltip("Parfait. Place maintenant la souris en bas-droite puis appuie sur {0}.".format(key_name), WARNING)
                time.sleep(0.4)
                if not self.wait_for_calib_or_esc():
                    self.show_message("❌ Calibration initiative annulée.", WARNING)
                    return
                bottom_right = self._capture_calibration_point(target_hwnd, "le coin bas-droite de l'initiative")
                if not bottom_right:
                    return
                region = self._capture_calibration_region(target_hwnd, top_left, bottom_right, "Zone Initiative", 10, 8)
                if not region:
                    return
                self.config.data.setdefault("macro_positions", {})["initiative_region"] = region
                self.config.save()
                self.show_message("✅ Zone Initiative calibrée.", SUCCESS)
            finally:
                self._end_calibration()

        return self._start_worker(worker)

    def start_calib_xp_drop(self):
        target_hwnd = self._resolve_calibration_hwnd()
        if not target_hwnd:
            return {"started": False}
        self.logic.focus_window(target_hwnd)
        time.sleep(0.2)
        key_name = (self.config.data.get("calib_key", "F4") or "F4").upper()
        self.show_tooltip("Lance un combat, place la souris sur le bouton XP/Drop puis appuie sur {0}.\n(Echap pour annuler)".format(key_name), WARNING)

        def worker():
            try:
                if self.wait_for_calib_or_esc():
                    pos = self._capture_calibration_point(target_hwnd, "le bouton XP/Drop")
                    if pos:
                        self.config.data.setdefault("macro_positions", {})["xp_drop_button"] = list(pos)
                        self.config.save()
                        self.show_message("✅ Bouton XP/Drop calibré.", SUCCESS)
            finally:
                self._end_calibration()

        return self._start_worker(worker)

    def start_calib_zaap(self):
        active_accounts = self.logic.get_cycle_list()
        if not active_accounts:
            self._report_error("Aucun compte actif pour calibrer les zaaps.")
            return {"started": False}
        key_name = (self.config.data.get("calib_key", "F4") or "F4").upper()
        self.show_tooltip("Le calibrage Zaap va parcourir chaque perso actif. Mets le curseur sur le haut du zaap puis appuie sur {0}.\n(Echap pour annuler)".format(key_name), WARNING)

        def worker():
            try:
                self.config.data.setdefault("macro_positions", {})["zaaps"] = {}
                for account in active_accounts:
                    self.logic.focus_window(account.get("hwnd"))
                    time.sleep(0.2)
                    self.show_tooltip("{0}: place la souris sur le haut du zaap puis appuie sur {1}.".format(account.get("name"), key_name), WARNING)
                    if not self.wait_for_calib_or_esc():
                        self.show_message("❌ Calibration Zaap annulée.", WARNING)
                        return
                    pos = self._capture_calibration_point(account.get("hwnd"), "le zaap de {0}".format(account.get("name")))
                    if not pos:
                        return
                    self.config.data.setdefault("macro_positions", {}).setdefault("zaaps", {})[account.get("name")] = list(pos)
                self.config.save()
                self.show_message("✅ Zaaps calibrés pour les comptes actifs.", SUCCESS)
            finally:
                self._end_calibration()

        return self._start_worker(worker)

    def start_calib_zone_jeu(self):
        target_hwnd = self._resolve_calibration_hwnd()
        if not target_hwnd:
            return {"started": False}
        self.logic.focus_window(target_hwnd)
        time.sleep(0.2)
        key_name = (self.config.data.get("calib_key", "F4") or "F4").upper()
        self.show_tooltip("Place la souris en haut-gauche de la zone de jeu puis {0}. Ensuite en bas-droite puis {0}.\n(Echap pour annuler)".format(key_name), WARNING)

        def worker():
            try:
                if not self.wait_for_calib_or_esc():
                    self.show_message("❌ Calibration zone de jeu annulée.", WARNING)
                    return
                top_left = self._capture_calibration_point(target_hwnd, "le coin haut-gauche de la zone de jeu")
                if not top_left:
                    return
                self.show_tooltip("Parfait. Place maintenant la souris en bas-droite de la zone de jeu puis appuie sur {0}.".format(key_name), WARNING)
                time.sleep(0.4)
                if not self.wait_for_calib_or_esc():
                    self.show_message("❌ Calibration zone de jeu annulée.", WARNING)
                    return
                bottom_right = self._capture_calibration_point(target_hwnd, "le coin bas-droite de la zone de jeu")
                if not bottom_right:
                    return
                region = self._capture_calibration_region(target_hwnd, top_left, bottom_right, "Zone de Jeu", 80, 80)
                if not region:
                    return
                self.config.data.setdefault("macro_positions", {})["game_zone"] = region
                self.config.save()
                self.show_message("✅ Zone de jeu calibrée.", SUCCESS)
            finally:
                self._end_calibration()

        return self._start_worker(worker)

    def start_calib_coord(self):
        target_hwnd = self._resolve_calibration_hwnd()
        if not target_hwnd:
            return {"started": False}
        self.logic.focus_window(target_hwnd)
        time.sleep(0.2)
        key_name = (self.config.data.get("calib_key", "F4") or "F4").upper()
        self.show_tooltip("Place la souris en haut-gauche de la boîte des coordonnées puis {0}. Ensuite en bas-droite puis {0}.\n(Echap pour annuler)".format(key_name), WARNING)

        def worker():
            try:
                if not self.wait_for_calib_or_esc():
                    self.show_message("❌ Calibration coordonnées annulée.", WARNING)
                    return
                top_left = self._capture_calibration_point(target_hwnd, "le coin haut-gauche des coordonnées")
                if not top_left:
                    return
                self.show_tooltip("Parfait. Place maintenant la souris en bas-droite de la boîte des coordonnées puis appuie sur {0}.".format(key_name), WARNING)
                time.sleep(0.4)
                if not self.wait_for_calib_or_esc():
                    self.show_message("❌ Calibration coordonnées annulée.", WARNING)
                    return
                bottom_right = self._capture_calibration_point(target_hwnd, "le coin bas-droite des coordonnées")
                if not bottom_right:
                    return
                region = self._capture_calibration_region(target_hwnd, top_left, bottom_right, "Zone Coordonnées", 12, 10)
                if not region:
                    return
                self.config.data.setdefault("macro_positions", {})["map_coords"] = region
                self.config.save()
                self.show_message("✅ Coordonnées calibrées.", SUCCESS)
            finally:
                self._end_calibration()

        return self._start_worker(worker)

    def start_calib_map_borders(self):
        target_hwnd = self._resolve_calibration_hwnd()
        if not target_hwnd:
            return {"started": False}
        self.logic.focus_window(target_hwnd)
        time.sleep(0.2)
        key_name = (self.config.data.get("calib_key", "F4") or "F4").upper()

        def worker():
            borders = (("top", "HAUT"), ("bottom", "BAS"), ("left", "GAUCHE"), ("right", "DROITE"))
            try:
                results = {}
                for border_key, label in borders:
                    self.show_tooltip("Place la souris sur le passage {0} puis appuie sur {1}.\n(Echap pour annuler)".format(label, key_name), WARNING)
                    time.sleep(0.3)
                    if not self.wait_for_calib_or_esc():
                        self.show_message("❌ Calibration bords de map annulée.", WARNING)
                        return
                    pos = self._capture_calibration_point(target_hwnd, "le passage {0}".format(label))
                    if not pos:
                        return
                    results[border_key] = list(pos)
                self.config.data.setdefault("macro_positions", {})["map_borders"] = results
                self.config.save()
                self.show_message("✅ Bords de map calibrés.", SUCCESS)
            finally:
                self._end_calibration()

        return self._start_worker(worker)

    def start_calib_group_accept(self):
        target_hwnd = self._resolve_calibration_hwnd()
        if not target_hwnd:
            return {"started": False}
        self.logic.focus_window(target_hwnd)
        time.sleep(0.2)
        key_name = (self.config.data.get("calib_key", "F4") or "F4").upper()
        self.show_tooltip("Ouvre une invitation de groupe, place la souris sur Accepter puis appuie sur {0}.\n(Echap pour annuler)".format(key_name), WARNING)

        def worker():
            try:
                if not self.wait_for_calib_or_esc():
                    self.show_message("❌ Calibration groupe annulée.", WARNING)
                    return
                pos = self._capture_calibration_point(target_hwnd, "le bouton Accepter")
                if not pos:
                    return
                self.config.data.setdefault("macro_positions", {})["group_accept_pos"] = list(pos)
                self.config.save()
                self.show_message("✅ Bouton Accepter calibré.", SUCCESS)
            finally:
                self._end_calibration()

        return self._start_worker(worker)

    def start_calib_trade_notif(self):
        target_hwnd = self._resolve_calibration_hwnd()
        if not target_hwnd:
            return {"started": False}
        self.logic.focus_window(target_hwnd)
        time.sleep(0.2)
        key_name = (self.config.data.get("calib_key", "F4") or "F4").upper()
        self.show_tooltip("Fais apparaître une notification d'échange, place la souris sur l'icône Dofus puis appuie sur {0}.\n(Echap pour annuler)".format(key_name), WARNING)

        def worker():
            try:
                if not self.wait_for_calib_or_esc():
                    self.show_message("❌ Calibration notification échange annulée.", WARNING)
                    return
                pos = self._capture_calibration_point(target_hwnd, "le pixel de notification d'échange")
                if not pos:
                    return
                rgb = self._sample_color(target_hwnd, pos)
                if not rgb:
                    self.show_message("❌ Impossible de lire la couleur du pixel.", ERROR)
                    return
                self.config.data.setdefault("macro_positions", {})["trade_notif_pos"] = [pos[0], pos[1], rgb[0], rgb[1], rgb[2]]
                self.config.save()
                self.show_message("✅ Pixel notification d'échange calibré.", SUCCESS)
            finally:
                self._end_calibration()

        return self._start_worker(worker)

    def start_calib_trade_notif2(self):
        target_hwnd = self._resolve_calibration_hwnd()
        if not target_hwnd:
            return {"started": False}
        self.logic.focus_window(target_hwnd)
        time.sleep(0.2)
        key_name = (self.config.data.get("calib_key", "F4") or "F4").upper()
        self.show_tooltip("[Optionnel] Place la souris sur le fond sombre de la notification puis appuie sur {0}.\n(Echap pour annuler)".format(key_name), WARNING)

        def worker():
            try:
                if not self.wait_for_calib_or_esc():
                    self.show_message("❌ Calibration pixel anti-faux-positif annulée.", WARNING)
                    return
                pos = self._capture_calibration_point(target_hwnd, "le second pixel de notification")
                if not pos:
                    return
                rgb = self._sample_color(target_hwnd, pos)
                if not rgb:
                    self.show_message("❌ Impossible de lire la couleur du pixel.", ERROR)
                    return
                self.config.data.setdefault("macro_positions", {})["trade_notif_pos2"] = [pos[0], pos[1], rgb[0], rgb[1], rgb[2]]
                self.config.save()
                self.show_message("✅ Pixel anti-faux-positif calibré.", SUCCESS)
            finally:
                self._end_calibration()

        return self._start_worker(worker)

    def start_calib_trade_validate(self):
        key_name = (self.config.data.get("calib_key", "F4") or "F4").upper()
        self.show_tooltip("Sur une fenêtre d'échange, place la souris sur le vert de validation puis appuie sur {0}.\n(Echap pour annuler)".format(key_name), WARNING)

        def worker():
            try:
                if not self.wait_for_calib_or_esc():
                    self.show_message("❌ Calibration pixel vert annulée.", WARNING)
                    return
                fg = win32gui.GetForegroundWindow()
                known = set(account.get("hwnd") for account in self.logic.get_cycle_list())
                if fg not in known:
                    self.show_message("❌ Mets une fenêtre Dofus active au premier plan.", ERROR)
                    return
                pos = self._capture_calibration_point(fg, "le pixel vert de validation")
                if not pos:
                    return
                rgb = self._sample_color(fg, pos)
                if not rgb:
                    self.show_message("❌ Impossible de lire la couleur du pixel.", ERROR)
                    return
                self.config.data.setdefault("macro_positions", {})["trade_validate_pos"] = [pos[0], pos[1], rgb[0], rgb[1], rgb[2]]
                self.config.save()
                self.show_message("✅ Pixel vert calibré.", SUCCESS)
            finally:
                self._end_calibration()

        return self._start_worker(worker)

    def start_calib_trade_validate_click(self):
        key_name = (self.config.data.get("calib_key", "F4") or "F4").upper()
        self.show_tooltip("Ouvre l'échange, place la souris sur le centre du bouton Valider puis appuie sur {0}.\n(Echap pour annuler)".format(key_name), WARNING)

        def worker():
            try:
                if not self.wait_for_calib_or_esc():
                    self.show_message("❌ Calibration bouton Valider annulée.", WARNING)
                    return
                fg = win32gui.GetForegroundWindow()
                known = set(account.get("hwnd") for account in self.logic.get_cycle_list())
                if fg not in known:
                    self.show_message("❌ Mets la fenêtre Dofus du bon perso au premier plan.", ERROR)
                    return
                pos = self._capture_calibration_point(fg, "le bouton Valider")
                if not pos:
                    return
                payload = [pos[0], pos[1]]
                rgb = self._sample_color(fg, pos)
                if rgb:
                    payload.extend([rgb[0], rgb[1], rgb[2]])
                self.config.data.setdefault("macro_positions", {})["trade_validate_click_pos"] = payload
                self.config.save()
                self.show_message("✅ Bouton Valider calibré.", SUCCESS)
            finally:
                self._end_calibration()

        return self._start_worker(worker)



















